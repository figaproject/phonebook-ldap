@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo Creating Python virtual environment...
  py -3 -m venv .venv
  if errorlevel 1 (
    python -m venv .venv
  )
)

call ".venv\Scripts\activate.bat"

if not exist ".venv\.deps_installed" (
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
  if errorlevel 1 exit /b 1
  echo ok>".venv\.deps_installed"
)

python app.py
