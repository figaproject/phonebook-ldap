# SIP Phonebook Server v8 — админка, автозапуск и справочник настроек SIP/IP телефонов

Проект запускается на Windows, хранит контакты в Excel-файле `data/contacts.xlsx` и отдаёт телефонную книгу через LDAP/HTTP для SIP/IP телефонов.

В этой версии добавлено:

- раздел **«Настройки SIP/IP телефонов»** на главной странице админки;
- раскрывающиеся карточки с готовыми параметрами для Grandstream, Yealink, Fanvil, Cisco, Snom, Poly/Polycom, Panasonic, Htek, Akuvox, Dinstar, Escene, Flyingvoice, Avaya, Mitel, Alcatel-Lucent, Unify;
- общие LDAP-параметры с текущим IP-адресом ПК, портом и Base DN;
- подсказка по правильному фильтру номера, чтобы короткие номера не совпадали с частью мобильного номера;
- сохранены функции v7: авторизация админки и автозапуск Windows.

## Логин и пароль админки

По умолчанию:

```text
Логин: admin
Пароль: 1234
```

Сразу после запуска лучше поменять пароль в `config.json`:

```json
"admin_auth_enabled": true,
"admin_username": "admin",
"admin_password": "ВАШ_НОВЫЙ_ПАРОЛЬ"
```

После изменения `config.json` перезапустите программу.

Если нужно временно отключить вход в админку:

```json
"admin_auth_enabled": false
```

## Запуск вручную

1. Распакуйте архив.
2. Запустите `run.bat`.
3. Откройте веб‑панель:

```text
http://127.0.0.1:8080
```

4. Введите логин и пароль администратора.

Контакты хранятся здесь:

```text
data/contacts.xlsx
```

Формат Excel:

| Number | Name |
|---|---|
| 100 | Reception |
| 101 | Иван Иванов |

Можно использовать русские заголовки `Номер` и `Имя`.

## Где смотреть настройки телефонов

После входа в админку откройте главную страницу. Там есть блок:

```text
Настройки SIP/IP телефонов
```

В нём есть:

- общие параметры LDAP;
- отдельные карточки производителей;
- HTTP XML/CSV ссылки как запасной вариант;
- подсказка по проверке подключения телефона.

## Автозапуск Windows

Сначала запустите `run.bat` вручную хотя бы один раз, чтобы создалась папка `.venv` и установились зависимости.

### Вариант 1 — автозапуск при входе пользователя

Запустите:

```text
install_autostart_user_login.bat
```

После этого сервер будет запускаться автоматически, когда текущий пользователь входит в Windows.

### Вариант 2 — автозапуск при загрузке Windows

Запустите **от имени администратора**:

```text
install_autostart_on_boot_admin.bat
```

Этот вариант создаёт задачу планировщика от имени `SYSTEM` и запускает проект после перезагрузки Windows.

### Проверить автозапуск

```text
check_autostart_status.bat
```

### Удалить автозапуск

```text
uninstall_autostart.bat
```

## Что запускается в автозагрузке

Автозагрузка запускает файл:

```text
run_background.vbs
```

Он скрыто запускает:

```text
run_server.bat
```

`run.bat` оставлен для ручного запуска с видимым окном.

## Важно про телефоны, LDAP и авторизацию

Админская авторизация защищает только веб‑панель управления.

LDAP для Yealink/Grandstream/Fanvil и HTTP XML/CSV для телефонов не требуют входа в админку, иначе телефоны не смогут автоматически получать книгу.

Если нужно отдельно закрыть HTTP XML/CSV логином и паролем, включите HTTP Basic Auth:

```json
"http_auth_enabled": true,
"http_auth_username": "phonebook",
"http_auth_password": "1234",
"http_auth_protect_web": false
```

Тогда в телефоне для HTTP‑книги укажите:

```text
Username: phonebook
Password: 1234
```

Для LDAP используется отдельная настройка:

```json
"ldap_allow_anonymous": true,
"ldap_bind_dn": "cn=admin,dc=phonebook,dc=local",
"ldap_password": "1234"
```

Если хотите, чтобы LDAP тоже требовал пароль:

```json
"ldap_allow_anonymous": false
```

В телефоне укажите:

```text
Username / Bind DN: cn=admin,dc=phonebook,dc=local
Password: 1234
```

## Универсальные настройки LDAP

```text
LDAP Server Address: IP_АДРЕС_ПК
LDAP Server Port: 389
Base DN: ou=contacts,dc=phonebook,dc=local
Username: пусто
Password: пусто
LDAP Name Attributes: cn displayName sn
LDAP Number Attributes: telephoneNumber mobile ipPhone
LDAP Display Name: %cn
LDAP Name Filter: (|(cn=%)(displayName=%)(sn=%))
LDAP Number Filter: (|(telephoneNumber=%)(mobile=%)(ipPhone=%))
```

## Защита от неправильного совпадения коротких номеров

Оставлены настройки v6:

```json
"ldap_number_match_mode": "exact_or_suffix",
"ldap_short_number_exact_digits": 5,
"ldap_suffix_match_min_digits": 7
```

Это значит, что короткий номер `140` ищется как точное совпадение `140`, а не внутри длинных мобильных номеров.

На телефонах, где можно вручную задавать LDAP Number Filter, используйте:

```text
(|(telephoneNumber=%)(mobile=%)(ipPhone=%))
```

Не используйте без необходимости:

```text
(|(telephoneNumber=*%*)(mobile=*%*)(ipPhone=*%*))
```

## Если порт 389 не запускается

Поменяйте порт LDAP в `config.json`, например:

```json
"ldap_port": 3389
```

И в телефоне тоже укажите порт `3389`.

Также проверьте Windows Firewall, VLAN и доступность ПК с телефона.
