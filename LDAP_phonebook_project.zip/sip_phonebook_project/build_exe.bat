@echo off
setlocal
cd /d "%~dp0"
call ".venv\Scripts\activate.bat" 2>nul
python -m pip install -r requirements.txt pyinstaller
pyinstaller --onefile --name SipPhonebookServer --add-data "templates;templates" --add-data "static;static" app.py
pause
