@echo off
setlocal
cd /d "%~dp0"
echo Installing SIP Phonebook autostart for current Windows user...
schtasks /Create /TN "SIP Phonebook Server" /SC ONLOGON /TR "wscript.exe \"%~dp0run_background.vbs\"" /F
if errorlevel 1 (
  echo.
  echo Failed to create scheduled task.
  echo Try running this file as Administrator, or use install_autostart_on_boot_admin.bat.
  pause
  exit /b 1
)
echo.
echo Done. SIP Phonebook will start automatically when this Windows user logs in.
echo You can remove it with uninstall_autostart.bat.
pause
