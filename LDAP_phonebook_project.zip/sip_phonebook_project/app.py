from __future__ import annotations

import csv
import hmac
import io
import json
import secrets
import socket
import tempfile
from pathlib import Path
from typing import Dict, List
from xml.etree import ElementTree as ET

from flask import (
    Flask,
    Response,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)
from waitress import serve

from ldap_server import LDAPConfig, start_ldap_server

from phonebook import (
    add_contact,
    delete_contact,
    ensure_workbook,
    import_contacts,
    load_contacts,
    save_contacts,
    update_contact,
)

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"
SESSION_SECRET_PATH = BASE_DIR / "admin_session.secret"


def load_config() -> Dict[str, object]:
    default = {
        "host": "0.0.0.0",
        "port": 8080,
        "phonebook_title": "Company Phonebook",
        "data_file": "data/contacts.xlsx",
        "web_page_size": 50,
        "web_page_limit": 50,
        "admin_auth_enabled": True,
        "admin_username": "admin",
        "admin_password": "1234",
        "http_auth_enabled": False,
        "http_auth_username": "phonebook",
        "http_auth_password": "1234",
        "http_auth_protect_web": False,
        "grandstream_max_contacts": 0,
        "grandstream_account_index": 1,
        "ldap_enabled": True,
        "ldap_host": "0.0.0.0",
        "ldap_port": 389,
        "ldap_base_dn": "ou=contacts,dc=phonebook,dc=local",
        "ldap_allow_anonymous": True,
        "ldap_bind_dn": "cn=admin,dc=phonebook,dc=local",
        "ldap_password": "1234",
        "ldap_respect_client_size_limit": False,
        "ldap_log_requests": True,
    }
    if CONFIG_PATH.exists():
        try:
            with CONFIG_PATH.open("r", encoding="utf-8") as f:
                default.update(json.load(f))
        except Exception:
            pass
    return default


CONFIG = load_config()
DATA_FILE = (BASE_DIR / str(CONFIG["data_file"])).resolve()
PHONEBOOK_TITLE = str(CONFIG.get("phonebook_title", "Company Phonebook"))
WEB_PAGE_SIZE = int(CONFIG.get("web_page_size", CONFIG.get("web_page_limit", 50)))
ADMIN_AUTH_ENABLED = bool(CONFIG.get("admin_auth_enabled", True))
ADMIN_USERNAME = str(CONFIG.get("admin_username", "admin"))
ADMIN_PASSWORD = str(CONFIG.get("admin_password", "1234"))
HTTP_AUTH_ENABLED = bool(CONFIG.get("http_auth_enabled", False))
HTTP_AUTH_USERNAME = str(CONFIG.get("http_auth_username", "phonebook"))
HTTP_AUTH_PASSWORD = str(CONFIG.get("http_auth_password", "1234"))
HTTP_AUTH_PROTECT_WEB = bool(CONFIG.get("http_auth_protect_web", False))
GRANDSTREAM_MAX_CONTACTS = int(CONFIG.get("grandstream_max_contacts", 2000))
GRANDSTREAM_ACCOUNT_INDEX = int(CONFIG.get("grandstream_account_index", 1))

app = Flask(__name__)


def get_or_create_session_secret() -> str:
    try:
        if SESSION_SECRET_PATH.exists():
            secret = SESSION_SECRET_PATH.read_text(encoding="utf-8").strip()
            if secret:
                return secret
        secret = secrets.token_urlsafe(48)
        SESSION_SECRET_PATH.write_text(secret, encoding="utf-8")
        return secret
    except Exception:
        return "sip-phonebook-local-editor-fallback-secret"


app.secret_key = get_or_create_session_secret()
ensure_workbook(DATA_FILE)


def auth_required_response() -> Response:
    return Response(
        "Authentication required",
        401,
        {"WWW-Authenticate": 'Basic realm="SIP Phonebook"'},
    )


def check_basic_auth() -> bool:
    auth = request.authorization
    if not auth:
        return False
    username_ok = hmac.compare_digest(auth.username or "", HTTP_AUTH_USERNAME)
    password_ok = hmac.compare_digest(auth.password or "", HTTP_AUTH_PASSWORD)
    return username_ok and password_ok


def path_needs_auth(path: str) -> bool:
    if path.startswith("/static"):
        return False
    if path.startswith("/phonebook") or path == "/phonebook.csv":
        return True
    # Legacy option. When form admin login is enabled, do not require
    # a second browser Basic Auth prompt for the same admin panel.
    return HTTP_AUTH_PROTECT_WEB and not ADMIN_AUTH_ENABLED


def is_admin_logged_in() -> bool:
    if not ADMIN_AUTH_ENABLED:
        return True
    return bool(session.get("admin_logged_in"))


def check_admin_login(username: str, password: str) -> bool:
    username_ok = hmac.compare_digest(username or "", ADMIN_USERNAME)
    password_ok = hmac.compare_digest(password or "", ADMIN_PASSWORD)
    return username_ok and password_ok


def safe_next_url(value: str | None) -> str:
    if value and value.startswith("/") and not value.startswith("//"):
        return value
    return url_for("index")


def is_admin_public_path(path: str) -> bool:
    if path.startswith("/static"):
        return True
    if path == "/login" or path == "/logout":
        return True
    # Phone endpoints stay independent from the admin panel.
    # Protect them separately with http_auth_enabled if needed.
    if path.startswith("/phonebook") or path == "/phonebook.csv":
        return True
    return False


@app.before_request
def protect_admin_panel():
    if not ADMIN_AUTH_ENABLED:
        return None
    if is_admin_public_path(request.path):
        return None
    if is_admin_logged_in():
        return None
    if request.method == "GET":
        return redirect(url_for("login", next=request.full_path.rstrip("?")))
    return redirect(url_for("login"))


@app.before_request
def optional_http_basic_auth():
    if not HTTP_AUTH_ENABLED:
        return None
    if not path_needs_auth(request.path):
        return None
    if check_basic_auth():
        return None
    return auth_required_response()


@app.after_request
def log_phonebook_requests(response: Response):
    if request.path.startswith("/phonebook") or request.path == "/phonebook.xml":
        print(
            f"[{response.status_code}] {request.remote_addr} {request.method} {request.path} "
            f"UA={request.headers.get('User-Agent', '-')}"
        )
    return response


def get_lan_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"


def xml_response(root: ET.Element) -> Response:
    data = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    return Response(data, mimetype="application/xml; charset=utf-8")


def contacts_for_view(all_contacts: List[Dict[str, str]]) -> tuple[List[Dict[str, object]], int, int, int, int]:
    """
    Paginated web output. LDAP/XML/CSV endpoints still use the full Excel file.
    """
    query = request.args.get("q", "").strip().lower()
    try:
        page = max(1, int(request.args.get("page", "1")))
    except ValueError:
        page = 1
    page_size = max(1, WEB_PAGE_SIZE)

    matched: List[tuple[int, Dict[str, str]]] = []
    for idx, contact in enumerate(all_contacts):
        if query and query not in contact["name"].lower() and query not in contact["number"].lower():
            continue
        matched.append((idx, contact))

    matched_count = len(matched)
    total_pages = max(1, (matched_count + page_size - 1) // page_size)
    page = min(page, total_pages)
    start = (page - 1) * page_size
    end = start + page_size
    visible = [{"index": idx, **contact} for idx, contact in matched[start:end]]
    return visible, matched_count, page, total_pages, page_size

@app.route("/login", methods=["GET", "POST"])
def login():
    if not ADMIN_AUTH_ENABLED:
        return redirect(url_for("index"))

    next_url = safe_next_url(request.values.get("next"))
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if check_admin_login(username, password):
            session.clear()
            session["admin_logged_in"] = True
            session["admin_username"] = username
            return redirect(next_url)
        flash("Неверный логин или пароль.", "error")

    return render_template(
        "login.html",
        title=PHONEBOOK_TITLE,
        next_url=next_url,
        admin_username=ADMIN_USERNAME,
    )


@app.get("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/")
def index():
    lan_ip = get_lan_ip()
    port = int(CONFIG.get("port", 8080))
    base_url = f"http://{lan_ip}:{port}"
    all_contacts = load_contacts(DATA_FILE)
    contacts, matched_count, page, total_pages, page_size = contacts_for_view(all_contacts)
    query = request.args.get("q", "")
    return render_template(
        "index.html",
        contacts=contacts,
        query=query,
        total=len(all_contacts),
        matched_count=matched_count,
        shown_count=len(contacts),
        page=page,
        total_pages=total_pages,
        page_size=page_size,
        title=PHONEBOOK_TITLE,
        data_file=str(DATA_FILE),
        base_url=base_url,
        http_auth_enabled=HTTP_AUTH_ENABLED,
        http_auth_username=HTTP_AUTH_USERNAME,
        http_auth_password=HTTP_AUTH_PASSWORD if HTTP_AUTH_ENABLED else "",
        http_auth_protect_web=HTTP_AUTH_PROTECT_WEB,
        ldap_enabled=bool(CONFIG.get("ldap_enabled", True)),
        ldap_port=int(CONFIG.get("ldap_port", 389)),
        ldap_base_dn=str(CONFIG.get("ldap_base_dn", "ou=contacts,dc=phonebook,dc=local")),
        ldap_allow_anonymous=bool(CONFIG.get("ldap_allow_anonymous", True)),
        ldap_bind_dn=str(CONFIG.get("ldap_bind_dn", "cn=admin,dc=phonebook,dc=local")),
        ldap_password=str(CONFIG.get("ldap_password", "1234")),
        admin_username=session.get("admin_username", ADMIN_USERNAME),
        admin_auth_enabled=ADMIN_AUTH_ENABLED,
    )


@app.post("/contacts/add")
def add_contact_route():
    number = request.form.get("number", "")
    name = request.form.get("name", "")
    if not number.strip() or not name.strip():
        flash("Заполните номер и имя.", "error")
    else:
        add_contact(DATA_FILE, number, name)
        flash("Контакт добавлен.", "ok")
    return redirect(url_for("index"))


@app.post("/contacts/<int:index>/edit")
def edit_contact_route(index: int):
    ok = update_contact(
        DATA_FILE,
        index,
        request.form.get("number", ""),
        request.form.get("name", ""),
    )
    flash("Контакт сохранён." if ok else "Контакт не найден.", "ok" if ok else "error")
    return redirect(url_for("index"))


@app.post("/contacts/<int:index>/delete")
def delete_contact_route(index: int):
    ok = delete_contact(DATA_FILE, index)
    flash("Контакт удалён." if ok else "Контакт не найден.", "ok" if ok else "error")
    return redirect(url_for("index"))


@app.post("/upload")
def upload():
    file = request.files.get("file")
    if not file or not file.filename.lower().endswith(".xlsx"):
        flash("Загрузите файл Excel .xlsx.", "error")
        return redirect(url_for("index"))

    with tempfile.TemporaryDirectory() as tmpdir:
        temp_path = Path(tmpdir) / "uploaded.xlsx"
        file.save(temp_path)
        count = import_contacts(temp_path, DATA_FILE)
    flash(f"Импортировано контактов: {count}.", "ok")
    return redirect(url_for("index"))


@app.get("/download")
def download():
    ensure_workbook(DATA_FILE)
    return send_file(DATA_FILE, as_attachment=True, download_name="contacts.xlsx")


@app.get("/api/contacts")
def api_contacts():
    return jsonify(load_contacts(DATA_FILE))


@app.get("/phonebook/yealink.xml")
def yealink_xml():
    root = ET.Element("YealinkIPPhoneDirectory")
    ET.SubElement(root, "Title").text = PHONEBOOK_TITLE
    for contact in load_contacts(DATA_FILE):
        entry = ET.SubElement(root, "DirectoryEntry")
        ET.SubElement(entry, "Name").text = contact["name"]
        ET.SubElement(entry, "Telephone").text = contact["number"]
    return xml_response(root)


@app.get("/phonebook/cisco.xml")
def cisco_xml():
    root = ET.Element("CiscoIPPhoneDirectory")
    ET.SubElement(root, "Title").text = PHONEBOOK_TITLE
    ET.SubElement(root, "Prompt").text = "Select contact"
    for contact in load_contacts(DATA_FILE):
        entry = ET.SubElement(root, "DirectoryEntry")
        ET.SubElement(entry, "Name").text = contact["name"]
        ET.SubElement(entry, "Telephone").text = contact["number"]
    return xml_response(root)


def split_grandstream_name(full_name: str) -> tuple[str, str]:
    """
    Grandstream XML supports FirstName and LastName.
    Keep compatibility with Russian/Excel lists by putting the full display name
    into LastName when there is no obvious split.
    """
    parts = str(full_name or "").strip().split(maxsplit=1)
    if not parts:
        return "", ""
    if len(parts) == 1:
        return parts[0], ""
    return parts[0], parts[1]


def build_grandstream_xml(limit: int | None = None) -> ET.Element:
    root = ET.Element("AddressBook")
    contacts = load_contacts(DATA_FILE)
    if limit and limit > 0:
        contacts = contacts[:limit]

    for contact in contacts:
        last_name, first_name = split_grandstream_name(contact["name"])
        entry = ET.SubElement(root, "Contact")
        ET.SubElement(entry, "LastName").text = last_name
        ET.SubElement(entry, "FirstName").text = first_name
        phone = ET.SubElement(entry, "Phone")
        ET.SubElement(phone, "phonenumber").text = contact["number"]
        # Grandstream accountindex is 1..6 for accounts 1..6.
        ET.SubElement(phone, "accountindex").text = str(GRANDSTREAM_ACCOUNT_INDEX)
        groups = ET.SubElement(entry, "Groups")
        ET.SubElement(groups, "groupid").text = "2"
    return root


@app.get("/phonebook/grandstream.xml")
@app.get("/phonebook.xml")
@app.get("/phonebook/phonebook.xml")
def grandstream_xml():
    return xml_response(build_grandstream_xml(GRANDSTREAM_MAX_CONTACTS))


@app.get("/phonebook/fanvil.xml")
def fanvil_xml():
    root = ET.Element("PhoneBook")
    menu = ET.SubElement(root, "Menu", {"Name": PHONEBOOK_TITLE})
    for contact in load_contacts(DATA_FILE):
        ET.SubElement(menu, "Unit", {"Name": contact["name"], "Phone1": contact["number"]})
    return xml_response(root)


@app.get("/phonebook.csv")
def phonebook_csv():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Name", "Telephone"])
    for contact in load_contacts(DATA_FILE):
        writer.writerow([contact["name"], contact["number"]])
    return Response(output.getvalue(), mimetype="text/csv; charset=utf-8")


@app.post("/replace-all")
def replace_all():
    names = request.form.getlist("name")
    numbers = request.form.getlist("number")
    contacts = []
    for number, name in zip(numbers, names):
        if number.strip() and name.strip():
            contacts.append({"number": number, "name": name})
    save_contacts(DATA_FILE, contacts)
    flash("Список сохранён.", "ok")
    return redirect(url_for("index"))


if __name__ == "__main__":
    host = str(CONFIG.get("host", "0.0.0.0"))
    port = int(CONFIG.get("port", 8080))
    lan_ip = get_lan_ip()

    ldap_cfg = LDAPConfig(
        enabled=bool(CONFIG.get("ldap_enabled", True)),
        host=str(CONFIG.get("ldap_host", "0.0.0.0")),
        port=int(CONFIG.get("ldap_port", 389)),
        base_dn=str(CONFIG.get("ldap_base_dn", "ou=contacts,dc=phonebook,dc=local")),
        allow_anonymous=bool(CONFIG.get("ldap_allow_anonymous", True)),
        bind_dn=str(CONFIG.get("ldap_bind_dn", "cn=admin,dc=phonebook,dc=local")),
        password=str(CONFIG.get("ldap_password", "1234")),
        respect_client_size_limit=bool(CONFIG.get("ldap_respect_client_size_limit", False)),
        title=PHONEBOOK_TITLE,
        data_file=DATA_FILE,
        log_requests=bool(CONFIG.get("ldap_log_requests", True)),
        number_match_mode=str(CONFIG.get("ldap_number_match_mode", "exact_or_suffix")),
        short_number_exact_digits=int(CONFIG.get("ldap_short_number_exact_digits", 5)),
        suffix_match_min_digits=int(CONFIG.get("ldap_suffix_match_min_digits", 7)),
    )

    print("=" * 64)
    print("SIP Phonebook Server")
    print(f"Web editor:       http://127.0.0.1:{port}")
    print(f"LAN editor:       http://{lan_ip}:{port}")
    print(f"Yealink XML:      http://{lan_ip}:{port}/phonebook/yealink.xml")
    print(f"Grandstream XML:  http://{lan_ip}:{port}/phonebook.xml")
    print(f"Fanvil XML:       http://{lan_ip}:{port}/phonebook/fanvil.xml")
    print(f"Cisco XML:        http://{lan_ip}:{port}/phonebook/cisco.xml")
    print(f"LDAP server:      ldap://{lan_ip}:{ldap_cfg.port}")
    print(f"LDAP Base DN:     {ldap_cfg.base_dn}")
    print("LDAP limit:       no application limit; all Excel contacts are searchable")
    print(f"LDAP number match:{ldap_cfg.number_match_mode}; short <= {ldap_cfg.short_number_exact_digits} digits exact only")
    if ldap_cfg.allow_anonymous:
        print("LDAP Auth:        anonymous bind allowed; username/password can be empty")
    else:
        print(f"LDAP Auth:        bind DN={ldap_cfg.bind_dn}")
    if ADMIN_AUTH_ENABLED:
        print(f"Admin panel:      login required, username={ADMIN_USERNAME}")
    else:
        print("Admin panel:      authorization disabled")
    if HTTP_AUTH_ENABLED:
        print(f"HTTP Phonebook:   auth enabled, username={HTTP_AUTH_USERNAME}")
    else:
        print("HTTP Phonebook:   auth disabled; leave username/password empty on HTTP phonebook")
    print("=" * 64)

    ldap_server = None
    try:
        ldap_server = start_ldap_server(ldap_cfg)
    except OSError as exc:
        print(f"LDAP server failed to start on port {ldap_cfg.port}: {exc}")
        print("Tip: check Windows Firewall, occupied port 389, or set ldap_port to 3389 in config.json.")

    serve(app, host=host, port=port)
