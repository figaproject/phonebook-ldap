from __future__ import annotations

import fnmatch
import re
import socketserver
import threading
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Tuple

from phonebook import load_contacts

# Minimal LDAPv3 server for SIP/IP phone remote phonebooks.
# It implements enough LDAP for Grandstream/Yealink/Fanvil style directory search:
# anonymous/simple bind, search requests, search result entries and unbind.

SUCCESS = 0
PROTOCOL_ERROR = 2
INVALID_CREDENTIALS = 49

NUMBER_ATTRIBUTES = {
    "telephonenumber",
    "mobile",
    "ipphone",
    "homephone",
    "othertelephone",
}


@dataclass
class LDAPConfig:
    host: str = "0.0.0.0"
    port: int = 389
    base_dn: str = "ou=contacts,dc=phonebook,dc=local"
    enabled: bool = True
    allow_anonymous: bool = True
    bind_dn: str = "cn=admin,dc=phonebook,dc=local"
    password: str = "1234"
    respect_client_size_limit: bool = False
    title: str = "Company Phonebook"
    data_file: Path = Path("data/contacts.xlsx")
    log_requests: bool = True
    number_match_mode: str = "exact_or_suffix"
    short_number_exact_digits: int = 5
    suffix_match_min_digits: int = 7


@dataclass
class SearchRequest:
    base_dn: str
    scope: int
    size_limit: int
    time_limit: int
    types_only: bool
    filter_tag: int
    filter_value: bytes
    attributes: List[str]


class BERDecodeError(ValueError):
    pass


def encode_length(length: int) -> bytes:
    if length < 0:
        raise ValueError("Negative BER length")
    if length < 128:
        return bytes([length])
    data = length.to_bytes((length.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(data)]) + data


def tlv(tag: int, content: bytes) -> bytes:
    return bytes([tag]) + encode_length(len(content)) + content


def encode_int_value(value: int) -> bytes:
    if value == 0:
        return b"\x00"
    data = value.to_bytes((value.bit_length() + 7) // 8, "big", signed=False)
    if data[0] & 0x80:
        data = b"\x00" + data
    return data


def ldap_int(value: int) -> bytes:
    return tlv(0x02, encode_int_value(value))


def ldap_enum(value: int) -> bytes:
    return tlv(0x0A, encode_int_value(value))


def ldap_bool(value: bool) -> bytes:
    return tlv(0x01, b"\xff" if value else b"\x00")


def ldap_str(value: object) -> bytes:
    return tlv(0x04, str(value or "").encode("utf-8"))


def sequence(*items: bytes) -> bytes:
    return tlv(0x30, b"".join(items))


def set_of(*items: bytes) -> bytes:
    return tlv(0x31, b"".join(items))


def ldap_message(message_id: int, protocol_op: bytes) -> bytes:
    return sequence(ldap_int(message_id), protocol_op)


def ldap_result_app(app_tag: int, result_code: int, diagnostic: str = "") -> bytes:
    return tlv(app_tag, ldap_enum(result_code) + ldap_str("") + ldap_str(diagnostic))


def bind_response(message_id: int, result_code: int = SUCCESS, diagnostic: str = "") -> bytes:
    return ldap_message(message_id, ldap_result_app(0x61, result_code, diagnostic))


def search_done(message_id: int, result_code: int = SUCCESS, diagnostic: str = "") -> bytes:
    return ldap_message(message_id, ldap_result_app(0x65, result_code, diagnostic))


def read_length(data: bytes, pos: int) -> Tuple[int, int]:
    if pos >= len(data):
        raise BERDecodeError("Missing BER length")
    first = data[pos]
    pos += 1
    if first < 128:
        return first, pos
    num_bytes = first & 0x7F
    if num_bytes == 0:
        raise BERDecodeError("Indefinite BER length is not supported")
    if pos + num_bytes > len(data):
        raise BERDecodeError("Truncated BER long length")
    return int.from_bytes(data[pos:pos + num_bytes], "big"), pos + num_bytes


def read_tlv(data: bytes, pos: int = 0) -> Tuple[int, bytes, int]:
    if pos >= len(data):
        raise BERDecodeError("Missing BER tag")
    tag = data[pos]
    length, pos2 = read_length(data, pos + 1)
    end = pos2 + length
    if end > len(data):
        raise BERDecodeError("Truncated BER value")
    return tag, data[pos2:end], end


def iter_tlvs(data: bytes) -> Iterable[Tuple[int, bytes]]:
    pos = 0
    while pos < len(data):
        tag, value, pos = read_tlv(data, pos)
        yield tag, value


def decode_int(value: bytes) -> int:
    if not value:
        return 0
    return int.from_bytes(value, "big", signed=bool(value[0] & 0x80))


def decode_str(value: bytes) -> str:
    return value.decode("utf-8", errors="replace")


def recv_exact(sock, count: int) -> bytes:
    chunks: List[bytes] = []
    remaining = count
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise ConnectionError("Client closed connection")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def recv_ldap_message(sock) -> bytes:
    header = recv_exact(sock, 2)
    tag = header[0]
    if tag != 0x30:
        raise BERDecodeError(f"Expected LDAPMessage sequence tag 0x30, got 0x{tag:02x}")
    first_len = header[1]
    if first_len < 128:
        length = first_len
        length_bytes = bytes([first_len])
    else:
        n = first_len & 0x7F
        if n == 0:
            raise BERDecodeError("Indefinite BER length is not supported")
        extra = recv_exact(sock, n)
        length = int.from_bytes(extra, "big")
        length_bytes = bytes([first_len]) + extra
    body = recv_exact(sock, length)
    return bytes([tag]) + length_bytes + body


def parse_ldap_message(packet: bytes) -> Tuple[int, int, bytes]:
    tag, body, end = read_tlv(packet, 0)
    if tag != 0x30 or end != len(packet):
        raise BERDecodeError("Invalid LDAPMessage")
    msg_tag, msg_value, pos = read_tlv(body, 0)
    if msg_tag != 0x02:
        raise BERDecodeError("LDAP messageID is missing")
    message_id = decode_int(msg_value)
    op_tag, op_value, _ = read_tlv(body, pos)
    return message_id, op_tag, op_value


def parse_bind_request(payload: bytes) -> Tuple[str, str]:
    # BindRequest ::= [APPLICATION 0] SEQUENCE { version, name, authentication }
    pos = 0
    _version_tag, _version_value, pos = read_tlv(payload, pos)
    name_tag, name_value, pos = read_tlv(payload, pos)
    if name_tag != 0x04:
        raise BERDecodeError("Bind DN is missing")
    bind_dn = decode_str(name_value)
    if pos >= len(payload):
        return bind_dn, ""
    auth_tag, auth_value, _ = read_tlv(payload, pos)
    # simple auth is context-specific primitive [0] = 0x80
    password = decode_str(auth_value) if auth_tag == 0x80 else ""
    return bind_dn, password


def parse_search_request(payload: bytes) -> SearchRequest:
    pos = 0
    base_tag, base_value, pos = read_tlv(payload, pos)
    scope_tag, scope_value, pos = read_tlv(payload, pos)
    _deref_tag, _deref_value, pos = read_tlv(payload, pos)
    size_tag, size_value, pos = read_tlv(payload, pos)
    time_tag, time_value, pos = read_tlv(payload, pos)
    types_tag, types_value, pos = read_tlv(payload, pos)
    filter_tag, filter_value, pos = read_tlv(payload, pos)
    attrs_tag, attrs_value, pos = read_tlv(payload, pos)

    if base_tag != 0x04 or scope_tag != 0x0A or size_tag != 0x02 or time_tag != 0x02 or types_tag != 0x01:
        raise BERDecodeError("Invalid SearchRequest fields")
    attributes: List[str] = []
    if attrs_tag == 0x30:
        for attr_tag, attr_value in iter_tlvs(attrs_value):
            if attr_tag == 0x04:
                attributes.append(decode_str(attr_value))
    return SearchRequest(
        base_dn=decode_str(base_value),
        scope=decode_int(scope_value),
        size_limit=decode_int(size_value),
        time_limit=decode_int(time_value),
        types_only=(types_value != b"\x00"),
        filter_tag=filter_tag,
        filter_value=filter_value,
        attributes=attributes,
    )


def split_name(full_name: str) -> Tuple[str, str]:
    parts = str(full_name or "").strip().split(maxsplit=1)
    if not parts:
        return "", ""
    if len(parts) == 1:
        return parts[0], parts[0]
    return parts[0], parts[1]


def dn_escape(value: str) -> str:
    value = str(value or "").strip()
    value = value.replace("\\", r"\5c").replace(",", r"\2c").replace("+", r"\2b").replace('"', r"\22")
    value = value.replace("<", r"\3c").replace(">", r"\3e").replace(";", r"\3b")
    if value.startswith("#"):
        value = r"\23" + value[1:]
    if value.startswith(" "):
        value = r"\20" + value[1:]
    if value.endswith(" "):
        value = value[:-1] + r"\20"
    return value or "contact"


def contact_attributes(contact: Dict[str, str], index: int, title: str) -> Dict[str, List[str]]:
    full_name = contact.get("name", "")
    number = contact.get("number", "")
    given_name, surname = split_name(full_name)
    return {
        "objectClass": ["top", "person", "organizationalPerson", "inetOrgPerson"],
        "cn": [full_name],
        "name": [full_name],
        "displayName": [full_name],
        "sn": [surname or full_name],
        "givenName": [given_name or full_name],
        "telephoneNumber": [number],
        "mobile": [number],
        "ipPhone": [number],
        "homePhone": [number],
        "otherTelephone": [number],
        "uid": [str(index + 1)],
        "o": [title],
    }


def attr_get(attrs: Dict[str, List[str]], requested: str) -> List[str]:
    requested_lower = requested.lower()
    for key, values in attrs.items():
        if key.lower() == requested_lower:
            return values
    return []


def wildcard_match(value: str, pattern: str) -> bool:
    value_l = value.lower()
    pattern_l = pattern.lower().replace("%", "*")
    if pattern_l in ("", "*"):
        return True
    if "*" in pattern_l:
        return fnmatch.fnmatchcase(value_l, pattern_l)
    return value_l == pattern_l or pattern_l in value_l


def is_number_attribute(attr: str) -> bool:
    return str(attr or "").lower() in NUMBER_ATTRIBUTES


def normalize_phone_number(value: str) -> str:
    return re.sub(r"\D+", "", str(value or ""))


def phone_number_matches(value: str, pattern: str, config: LDAPConfig) -> bool:
    """Match phone numbers safely.

    Grandstream can send substring LDAP filters such as *140*. For short internal
    extensions this must NOT match inside long mobile numbers. The default mode
    requires exact match for short numbers and allows suffix matching only for
    longer external numbers, so +7/8/10-digit formats still work.
    """
    number_digits = normalize_phone_number(value)
    query_digits = normalize_phone_number(pattern)

    if not query_digits:
        return True
    if not number_digits:
        return False
    if number_digits == query_digits:
        return True

    mode = str(config.number_match_mode or "exact_or_suffix").lower().strip()
    if mode == "contains":
        return query_digits in number_digits
    if mode not in ("exact_or_suffix", "suffix"):
        return False

    short_limit = max(1, int(config.short_number_exact_digits or 5))
    min_suffix = max(short_limit + 1, int(config.suffix_match_min_digits or 7))

    # A short extension like 140 must only match 140 exactly.
    if len(query_digits) <= short_limit or len(number_digits) <= short_limit:
        return False

    compare_len = min(len(query_digits), len(number_digits))
    if compare_len < min_suffix:
        return False

    # Try decreasing suffix lengths. This handles +7/8/10-digit variants:
    # +7 921 123-45-67, 8 921 123-45-67 and 9211234567 all match.
    for suffix_len in range(compare_len, min_suffix - 1, -1):
        if number_digits[-suffix_len:] == query_digits[-suffix_len:]:
            return True
    return False


def filter_matches(tag: int, value: bytes, attrs: Dict[str, List[str]], config: LDAPConfig) -> bool:
    try:
        if tag == 0xA0:  # and
            return all(filter_matches(child_tag, child_value, attrs, config) for child_tag, child_value in iter_tlvs(value))
        if tag == 0xA1:  # or
            return any(filter_matches(child_tag, child_value, attrs, config) for child_tag, child_value in iter_tlvs(value))
        if tag == 0xA2:  # not
            child_tag, child_value, _ = read_tlv(value, 0)
            return not filter_matches(child_tag, child_value, attrs, config)
        if tag in (0xA3, 0xA5, 0xA6, 0xA8):  # equality/ge/le/approx: attr + assertionValue
            pos = 0
            attr_tag, attr_value, pos = read_tlv(value, pos)
            val_tag, val_value, _ = read_tlv(value, pos)
            if attr_tag != 0x04 or val_tag != 0x04:
                return True
            attr = decode_str(attr_value)
            assertion = decode_str(val_value)
            values = attr_get(attrs, attr)
            if is_number_attribute(attr):
                return any(phone_number_matches(item, assertion, config) for item in values)
            return any(wildcard_match(item, assertion) for item in values)
        if tag == 0xA4:  # substrings
            pos = 0
            attr_tag, attr_value, pos = read_tlv(value, pos)
            seq_tag, seq_value, _ = read_tlv(value, pos)
            if attr_tag != 0x04 or seq_tag != 0x30:
                return True
            attr = decode_str(attr_value)
            parts = []
            for p_tag, p_value in iter_tlvs(seq_value):
                if p_tag in (0x80, 0x81, 0x82):
                    parts.append(decode_str(p_value))
            pattern = "*" + "*".join(parts) + "*"
            values = attr_get(attrs, attr)
            if is_number_attribute(attr):
                return any(phone_number_matches(item, pattern, config) for item in values)
            return any(wildcard_match(item, pattern) for item in values)
        if tag == 0x87:  # present
            attr = decode_str(value)
            return bool(attr_get(attrs, attr)) or attr == "objectClass"
    except Exception:
        return True
    # Unknown filter: do not break phones, return the entry.
    return True


def select_attributes(attrs: Dict[str, List[str]], requested: List[str], types_only: bool) -> Dict[str, List[str]]:
    if requested and "1.1" in requested:
        return {}
    include_all = not requested or "*" in requested
    selected: Dict[str, List[str]] = {}
    if include_all:
        selected.update(attrs)
    else:
        for req in requested:
            for key, values in attrs.items():
                if key.lower() == req.lower():
                    selected[key] = values
                    break
    if types_only:
        return {key: [] for key in selected}
    return selected


def search_entry(message_id: int, dn: str, attrs: Dict[str, List[str]]) -> bytes:
    attr_items: List[bytes] = []
    for attr_name, values in attrs.items():
        value_set = set_of(*(ldap_str(v) for v in values if v is not None))
        attr_items.append(sequence(ldap_str(attr_name), value_set))
    app = tlv(0x64, ldap_str(dn) + sequence(*attr_items))
    return ldap_message(message_id, app)


class LDAPRequestHandler(socketserver.BaseRequestHandler):
    server: "PhonebookLDAPServer"

    def handle(self) -> None:
        while True:
            try:
                packet = recv_ldap_message(self.request)
                message_id, op_tag, op_value = parse_ldap_message(packet)
            except (ConnectionError, OSError):
                return
            except Exception as exc:
                if self.server.config.log_requests:
                    print(f"[LDAP] bad packet from {self.client_address[0]}: {exc}")
                return

            try:
                if op_tag == 0x60:  # BindRequest
                    bind_dn, password = parse_bind_request(op_value)
                    ok = self.server.authenticate(bind_dn, password)
                    if self.server.config.log_requests:
                        user = bind_dn or "anonymous"
                        print(f"[LDAP] {self.client_address[0]} bind user={user} result={'OK' if ok else 'FAIL'}")
                    if ok:
                        self.request.sendall(bind_response(message_id, SUCCESS))
                    else:
                        self.request.sendall(bind_response(message_id, INVALID_CREDENTIALS, "Invalid credentials"))
                elif op_tag == 0x63:  # SearchRequest
                    search = parse_search_request(op_value)
                    sent = self.server.send_search_results(self.request, message_id, search)
                    if self.server.config.log_requests:
                        print(
                            f"[LDAP] {self.client_address[0]} search base='{search.base_dn}' "
                            f"attrs={search.attributes or ['*']} sent={sent}"
                        )
                elif op_tag == 0x42:  # UnbindRequest
                    return
                else:
                    self.request.sendall(search_done(message_id, PROTOCOL_ERROR, f"Unsupported LDAP operation 0x{op_tag:02x}"))
            except Exception as exc:
                if self.server.config.log_requests:
                    print(f"[LDAP] error: {exc}")
                    traceback.print_exc()
                try:
                    self.request.sendall(search_done(message_id, PROTOCOL_ERROR, str(exc)))
                except Exception:
                    return


class PhonebookLDAPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, server_address: Tuple[str, int], config: LDAPConfig):
        super().__init__(server_address, LDAPRequestHandler)
        self.config = config

    def authenticate(self, bind_dn: str, password: str) -> bool:
        if not bind_dn and not password:
            return self.config.allow_anonymous
        return bind_dn.lower() == self.config.bind_dn.lower() and password == self.config.password

    def send_search_results(self, sock, message_id: int, search: SearchRequest) -> int:
        contacts = load_contacts(self.config.data_file)
        sent = 0
        client_limit = search.size_limit if self.config.respect_client_size_limit and search.size_limit > 0 else 0
        for index, contact in enumerate(contacts):
            attrs = contact_attributes(contact, index, self.config.title)
            if not filter_matches(search.filter_tag, search.filter_value, attrs, self.config):
                continue
            dn = f"cn={dn_escape(contact.get('name', ''))}-{index + 1},{self.config.base_dn}"
            selected = select_attributes(attrs, search.attributes, search.types_only)
            sock.sendall(search_entry(message_id, dn, selected))
            sent += 1
            if client_limit and sent >= client_limit:
                break
        sock.sendall(search_done(message_id, SUCCESS))
        return sent


def start_ldap_server(config: LDAPConfig) -> Optional[PhonebookLDAPServer]:
    if not config.enabled:
        print("LDAP server:      disabled")
        return None
    server = PhonebookLDAPServer((config.host, config.port), config)
    thread = threading.Thread(target=server.serve_forever, name="LDAPPhonebookServer", daemon=True)
    thread.start()
    return server
