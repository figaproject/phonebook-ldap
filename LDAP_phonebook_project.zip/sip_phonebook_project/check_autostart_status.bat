@echo off
schtasks /Query /TN "SIP Phonebook Server" /V /FO LIST
pause
