from __future__ import annotations

import re
import threading
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

LOCK = threading.RLock()

NUMBER_ALIASES = {
    "number", "phone", "telephone", "tel", "extension", "ext",
    "номер", "телефон", "внутренний", "доб", "добавочный",
}
NAME_ALIASES = {
    "name", "display name", "contact", "fullname", "full name",
    "имя", "фио", "контакт", "абонент", "сотрудник", "название",
}


def _norm_header(value: object) -> str:
    return str(value or "").strip().lower().replace("№", "номер")


def clean_number(value: object) -> str:
    """Keep digits and common phone symbols used by PBX/IP phones."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    # Remove spaces, brackets and dashes but keep +, *, #, commas and semicolons.
    return re.sub(r"[\s()\-]", "", raw)


def clean_name(value: object) -> str:
    return str(value or "").strip()


def ensure_workbook(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        return
    save_contacts(path, [])


def _detect_columns(rows: List[Tuple[object, ...]]) -> Tuple[int, int, int]:
    """
    Return (header_row_index, number_col, name_col).
    If no header is found, assume first two columns are Number, Name.
    """
    for row_index, row in enumerate(rows[:5]):
        normalized = [_norm_header(v) for v in row]
        number_col = None
        name_col = None
        for i, value in enumerate(normalized):
            if value in NUMBER_ALIASES:
                number_col = i
            if value in NAME_ALIASES:
                name_col = i
        if number_col is not None and name_col is not None:
            return row_index, number_col, name_col

    # No header. User described Excel as "number, name", so A=Number, B=Name.
    return -1, 0, 1


def load_contacts(path: Path) -> List[Dict[str, str]]:
    with LOCK:
        ensure_workbook(path)
        wb = load_workbook(path, data_only=True)
        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            return []

        header_row, number_col, name_col = _detect_columns(rows)
        start_row = header_row + 1 if header_row >= 0 else 0
        contacts: List[Dict[str, str]] = []

        for row in rows[start_row:]:
            number = clean_number(row[number_col] if len(row) > number_col else "")
            name = clean_name(row[name_col] if len(row) > name_col else "")
            if not number and not name:
                continue
            if not number or not name:
                # Skip incomplete rows; they can break some phone XML parsers.
                continue
            contacts.append({"number": number, "name": name})

        return contacts


def save_contacts(path: Path, contacts: Iterable[Dict[str, str]]) -> None:
    with LOCK:
        path.parent.mkdir(parents=True, exist_ok=True)
        wb = Workbook()
        ws = wb.active
        ws.title = "Contacts"
        ws.append(["Number", "Name"])
        for item in contacts:
            number = clean_number(item.get("number", ""))
            name = clean_name(item.get("name", ""))
            if number and name:
                ws.append([number, name])

        header_fill = PatternFill("solid", fgColor="1F4E78")
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center")
        ws.column_dimensions["A"].width = 24
        ws.column_dimensions["B"].width = 36
        ws.freeze_panes = "A2"
        wb.save(path)


def add_contact(path: Path, number: str, name: str) -> None:
    contacts = load_contacts(path)
    contacts.append({"number": number, "name": name})
    save_contacts(path, contacts)


def update_contact(path: Path, index: int, number: str, name: str) -> bool:
    contacts = load_contacts(path)
    if index < 0 or index >= len(contacts):
        return False
    contacts[index] = {"number": number, "name": name}
    save_contacts(path, contacts)
    return True


def delete_contact(path: Path, index: int) -> bool:
    contacts = load_contacts(path)
    if index < 0 or index >= len(contacts):
        return False
    del contacts[index]
    save_contacts(path, contacts)
    return True


def import_contacts(source_xlsx: Path, target_xlsx: Path) -> int:
    contacts = load_contacts(source_xlsx)
    save_contacts(target_xlsx, contacts)
    return len(contacts)
