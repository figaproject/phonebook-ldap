@echo off
setlocal
cd /d "%~dp0"
echo Installing SIP Phonebook autostart on Windows boot...
echo This script must be run as Administrator.
echo Recommended: run run.bat once before this script so .venv is already created.
schtasks /Create /TN "SIP Phonebook Server" /SC ONSTART /RU SYSTEM /RL HIGHEST /TR "wscript.exe \"%~dp0run_background.vbs\"" /F
if errorlevel 1 (
  echo.
  echo Failed. Right-click this file and choose Run as administrator.
  pause
  exit /b 1
)
echo.
echo Done. SIP Phonebook will start automatically after Windows boot.
echo You can remove it with uninstall_autostart.bat.
pause
