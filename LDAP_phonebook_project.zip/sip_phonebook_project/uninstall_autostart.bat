@echo off
setlocal
echo Removing SIP Phonebook autostart task...
schtasks /Delete /TN "SIP Phonebook Server" /F
if errorlevel 1 (
  echo Task not found or no rights to remove it.
) else (
  echo Done.
)
pause
